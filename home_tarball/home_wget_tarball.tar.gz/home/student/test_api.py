#!/usr/bin/env python3

""" Demo of the importance of methods """

import requests

# GET, POST, PUT, DELETE
resp=requests.get("http://api.open-notify.org/astros.json")

print(dir(resp))
print(resp.status_code)
print(resp.text)
